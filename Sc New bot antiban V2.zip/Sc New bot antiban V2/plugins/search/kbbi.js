const KBBI = require('kbbi.js');

exports.run = {
   usage: ['kbbi'],
   use: 'word',
   category: 'search',
   async: async (m, { client, Func, args, isPrefix, command }) => {
      try {
         if (!args[0]) return client.reply(m.chat, `• Example : ${isPrefix + command} pohon`, m);

         const keyword = args[0];

         KBBI.cari(keyword)
            .then(response => {
               if (response.arti.length > 0) {
                  const caption = `*❒ KBBI - ${keyword}*\n\n`
                     + response.arti.map((arti, index) => `  ○ *Definition ${index + 1}:* ${arti}`).join('\n');

                  client.reply(m.chat, caption + '\n\n' + global.footer, m);
               } else {
                  client.reply(m.chat, Func.texted('bold', '❌ Word not found in KBBI.'), m);
               }
            })
            .catch(error => {
               console.error(error);
               client.reply(m.chat, Func.jsonFormat(error), m);
            });
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   limit: true,
   location: __filename
};