const fetch = require('node-fetch');
const md5 = require('md5');
const FormData = require('form-data');

exports.run = {
   usage: ['nick-hago'],
   use: '<user id>',
   category: 'nickname game',
   async: async (m, { client, args, isPrefix, command }) => {
      try {
         if (!args[0]) return client.reply(m.chat, `🚩 *Masukkan iduser*
         
• Contoh :
${isPrefix + command} id_user`, m);
         const apiKey = process.env.VIPA_API_KEY;
         const apiId = process.env.VIPA_API_ID;
         const userId = args[0];

         const formData = new FormData();
         formData.append("key", apiKey);

         // Hitung nilai md5(API ID + API KEY)
         const md5Value = md5(apiId + apiKey);
         formData.append("sign", md5Value);

         formData.append("type", "get-nickname");
         formData.append("code", "hago");
         formData.append("target", userId);

         // Lakukan request menggunakan fetch
         const response = await fetch("https://vip-reseller.co.id/api/game-feature", {
            method: "POST",
            body: formData
         });

         const responseData = await response.json();
         if (response.ok && responseData.result) {
            const nickname = responseData.data;
            const reply = `*Nickname Game*\n\nUser ID: ${userId}\nZone ID: ${zoneId}\nNickname: ${nickname}`;
            client.reply(m.chat, reply, m);
         } else {
            const errorMessage = responseData.message || 'Gagal mendapatkan nickname game';
            return client.reply(m.chat, `🚩 ${errorMessage}`, m);
         }
      } catch (e) {
         return client.reply(m.chat, `error`, m);
      }
   },
   error: false,
   location: __filename
};