const axios = require('axios');
const cheerio = require('cheerio');

exports.run = {
   usage: ['geticon-website'],
   use: 'url',
   category: 'website',
   async: async (m, { client, args, isPrefix, command }) => {
      try {
         if (!args[0]) return client.reply(m.chat, Func.example(isPrefix, command, 'https://yanamiku.shop'), m);

         const url = args[0];
         const response = await axios.get(url);
         const html = response.data;
         const $ = cheerio.load(html);

         const iconUrl = $('link[rel="icon"]').attr('href');

         if (!iconUrl) {
            return client.reply(m.chat, '❌ Website does not have an icon.', m);
         }

         const fileBuffer = await axios.get(iconUrl, { responseType: 'arraybuffer' });
         const caption = `🖼️ *Icon from ${url}*`;
         client.sendFile(m.chat, Buffer.from(fileBuffer.data), 'icon.jpg', caption, m);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, '❌ An error occurred while fetching the website icon.', m);
      }
   },
   error: false,
   limit: true,
   location: __filename
};