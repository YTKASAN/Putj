const fetch = require('node-fetch');

exports.run = {
   usage: ['kodepos'],
   use: 'code',
   category: 'search',
   async: async (m, { client, Func, args, isPrefix, command }) => {
      try {
         if (!args[0]) return client.reply(m.chat, `🚩 Berikan argumen berupa kodepos

• Example : ${isPrefix + command} 52194`, m);
         
         const kodepos = args[0];
         client.sendReact(m.chat, '🕘', m.key);

         const rawUrl = `https://raw.githubusercontent.com/YanaMiku-Project/database-public/main/json/kodepos.json`;

         const response = await fetch(rawUrl);
         const data = await response.json();

         const results = data.filter(entry => entry.postal_code === kodepos);

         if (results.length > 0) {
            const caption = `*❒ K O D E P O S - I N F O*\n\n`
               + results.map((result, index) => {
                  return `○ *Result ${index + 1}:*\n`
                     + `  ○ *Province:* ${result.province}\n`
                     + `  ○ *City:* ${result.city}\n`
                     + `  ○ *District:* ${result.district}\n`
                     + `  ○ *Subdistrict:* ${result.subdistrict}\n`
                     + `  ○ *Postal Code:* ${result.postal_code}\n`;
               }).join('\n');

            client.reply(m.chat, caption + '\n' + global.footer, m);
            client.sendReact(m.chat, '✅', m.key);
         } else {
            client.reply(m.chat, Func.texted('bold', '❌ Postal code not found.'), m);
         }
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   limit: true, 
   location: __filename
};