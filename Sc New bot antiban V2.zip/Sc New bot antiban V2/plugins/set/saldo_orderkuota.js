const fetch = require('node-fetch');

exports.run = {
   usage: ['saldo-orderkuota'],
   category: 'owner',
   async: async (m, { client, Func }) => {
      try {
         const web = process.env.ORDERKUOTA_WEB;
         const id = process.env.ORDERKUOTA_ID;
         const pin = process.env.ORDERKUOTA_PIN;
         const psswd = process.env.ORDERKUOTA_PASSWORD;
         const apiUrl = `${web}/trx/balance?memberID=${id}&pin=${pin}&password=${psswd}`;

         const requestOptions = {
            method: 'GET',
            redirect: 'follow'
         };

         const response = await fetch(apiUrl, requestOptions);
         const result = await response.text();

         await client.reply(m.chat, result, m);
      } catch (e) {
         console.error(e);
         await client.reply(m.chat, global.status.error, m);
      }
   },
   error: false,
   owner: true, 
   location: __filename
};