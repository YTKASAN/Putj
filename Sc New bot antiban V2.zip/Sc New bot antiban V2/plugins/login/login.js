exports.run = {
   usage: ['login'],
   category: 'manage account',
   async: async (m, {
      client,
      Func, 
      users, 
      command, 
      isPrefix
   }) => {
      try {
         users.login_username = true;
         users.login_password = false;
         users.stat_email = false;
         users.stat_password = false;
         users.stat_username = false;
         users.email = '';
         users.password = '';
         users.username = '';
         client.reply(m.chat, '🚩 Silahkan kirimkan *Username*', m)
      } catch (e) {
         console.log(e);
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   private: true,
   location: __filename
}